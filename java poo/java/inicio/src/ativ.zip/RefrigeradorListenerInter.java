import javax.swing.*;

public interface RefrigeradorListenerInter {
    
    void modancaTemp(float temp);
}
