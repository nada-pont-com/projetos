import static java.lang.Thread.sleep;

public class Main {
    public static void main(String[] args) {
        Geladeira geladeira = Geladeira.getInstance();
        geladeira.selecionarTemperatura(1);
        Janela jp = new Janela();
        jp.setVisible(true);

    }
}
