import javax.swing.*;
import java.awt.*;

public class Janela extends JFrame {
    private final JLabel txt;

    public Janela(){
        setTitle("Notepad");
        setLayout(new BorderLayout());
        txt = new JLabel();
        add(txt, BorderLayout.CENTER);
        pack();
        Geladeira.getInstance().getRefrigerador().addListener(new RefrigeradorListener(txt));
    }

}


/*
* Geladeira.getInstance().getRefrigerador().addListener(new RefrigeradorListener(){});
* */
