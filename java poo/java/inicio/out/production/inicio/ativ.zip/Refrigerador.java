import java.util.ArrayList;

public class Refrigerador {
    protected float temperaturaSelecionada;
    protected Carga ventilador;
    protected SensorDeTemperatura sensorTemperaturaAtual;
    protected float temAnterior;
    private final ArrayList<RefrigeradorListener> listaDeListeners = new ArrayList<>();

    public Refrigerador(){
        ventilador = new Carga();
        sensorTemperaturaAtual = new SensorDeTemperatura();
        temAnterior = sensorTemperaturaAtual.getTemperaturaAtual();
    }

    public float getTemperatura(){ return sensorTemperaturaAtual.getTemperaturaAtual();}
    
    //Setter para temperatura (Celsius).
    public void selecionarTemperatura(float temperatura) {
        temperaturaSelecionada = temperatura;
    }
    
    public void controlarTemperatura() {
        if(temAnterior!=sensorTemperaturaAtual.getTemperaturaAtual()){
            executa();
            temAnterior = sensorTemperaturaAtual.getTemperaturaAtual();
        }
        if(sensorTemperaturaAtual.getTemperaturaAtual() > temperaturaSelecionada) {
            ventilador.ligar();
        } else {
            ventilador.desligar();
        }
    }

    public void executa(){
        for (RefrigeradorListener a: listaDeListeners) {
            a.atualizaText(sensorTemperaturaAtual.getTemperaturaAtual());
        }
    }

    public void addListener(RefrigeradorListener a) {
        listaDeListeners.add(a);
    }
}