import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RefrigeradorListener implements ActionListener {
    JLabel txt;

    RefrigeradorListener(JLabel txt){
        super();
        this.txt = txt;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    public void atualizaText(float temp){
        txt.setText("Temperatura "+temp);
    }
}
