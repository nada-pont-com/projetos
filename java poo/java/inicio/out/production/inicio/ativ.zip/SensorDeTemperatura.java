import java.util.Random;

public class SensorDeTemperatura extends Thread{

    SensorDeTemperatura(){
        super();
        this.start();
    }

    @Override
    public void run() {
        Random random = new Random();
        while (true){
            this.setTemperaturaAtual(random.nextInt(1000) + random.nextFloat());
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    private float temperaturaAtual;
    
    public float getTemperaturaAtual() {
        return temperaturaAtual;
    }

    public void setTemperaturaAtual(float temperaturaAtual) {
        this.temperaturaAtual = temperaturaAtual;
    }
}
