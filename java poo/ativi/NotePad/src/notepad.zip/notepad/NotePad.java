/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notepad;

/**
 *
 * @author vinicius
 */
public class NotePad {
    public static void main(String[] args) {
        NotePadTela tela1 = new NotePadTela();
        tela1.setVisible(true);
        System.out.println(tela1);
        System.out.println("ola mundo   ");
    }
    
}
