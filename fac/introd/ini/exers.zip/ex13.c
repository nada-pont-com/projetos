#include <stdio.h>
#include <stdlib.h>

int main(){
    int value = 1,num,valor;
    int menor = 101,maior = -1, valida = 1;
    num = rand()%101;
    printf("Mentalize um numero de 0 a 100\n");
    do{
        valida = 1;
        printf("O numero %d e:\n1 - menor\n2 - maior\n3 - o numero\n",num);
        scanf("%d",&valor);
        printf("\n\n");
        if(valor == 3)
            break;
        if(valor == 2)
            maior = num;
        else
            menor = num;
        do{
            num = rand()%101;
            if((num>maior)&&(num<menor)){
                valida = 0;
            }
        } while (valida);
    } while (value);
    return 0;
}
