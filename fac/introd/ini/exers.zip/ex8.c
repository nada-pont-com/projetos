#include <stdio.h>
#include <stdlib.h>

int main(){
    int num;
    printf("digite q1uantos valores voce quer comparar:\n");
    scanf("%d",&num);
    int armz[2];
    int vetor [num];
    for(int i=0;i<num;i++){
        printf("digite os valores:\n ");
        scanf("%d",&vetor[i]);
    }
    armz[0]=vetor[0];

    for (int i = 1; i < num; i++){    
        if((vetor[i]>armz[0])||(vetor[i]>armz[1])){
            armz[1]=armz[0];
            armz[0]=vetor[i];
        }
    }

    printf("Os maiores valores sao %d e %d\n",armz[0],armz[1]);
}